<?php

$dataTypeMap = array();

$dataTypeMap["order"]=1;
$dataTypeMap["rider"]=2;
$dataTypeMap["order dubious"]=3;
$dataTypeMap["rider position"]=4;
$dataTypeMap["order payment"]=5;
$dataTypeMap["order illegal"]=6;