<?php

$OrderStateMap = array();
$OrderStateMap["orderadd"]=1;
$OrderStateMap["orderdistr"]=2;
$OrderStateMap["orderuntake"]=3;
$OrderStateMap["ordertake"]=4;
$OrderStateMap["orderfinish"]=5;
$OrderStateMap["ordercancel"]=6;
$OrderStateMap["orderdubious"]=7;
$OrderStateMap["orderpayment"]=8;
$OrderStateMap["orderillegal"]=9;