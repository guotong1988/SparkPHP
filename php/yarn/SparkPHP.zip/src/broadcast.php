<?php

class broadcast{
    # Holds broadcasted data received from Java, keyed by its id.
   var $broadcastRegistry=array();
   function __construct(context $sc=null, $value=null, $path=null){



   }

}