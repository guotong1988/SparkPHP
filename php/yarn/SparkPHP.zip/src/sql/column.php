<?php



function _create_column_from_name($name)
{
}

#TODO 先用string
$_to_java_column = function ($col)
{
    $jcol = _create_column_from_name($col);
    return $jcol;
};