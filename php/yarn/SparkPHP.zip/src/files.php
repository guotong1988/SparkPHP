<?php

class spark_files{
var $root_directory = null;
var $is_running_on_worker = False;
var $sc = null;

}